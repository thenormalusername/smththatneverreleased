To compile:

`make`

To run:

`./main`

Change number of threads and minimal output size in main.c

Option MINIMALIST_OUTPUT when turned on, writes only seed into the file so cubiomes viewer can take it. Turned off by default, change 0 to 1 to turn on. Doesnt change output in terminal.
