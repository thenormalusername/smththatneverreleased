#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>

#include "cubiomes/biomenoise.h"
//#include "cubiomes/finders.h"
#include "cubiomes/generator.h"

#define THREADS 24
#define BATCH_SIZE 16384
#define MIN_SIZE 40000
#define MINIMALIST_OUTPUT 1

typedef struct {
  BiomeNoise *t, *h, *c, *e, *w;
} ClimateNoises;

typedef struct {
  double t, h, c, e, w;
} ClimateValues;


static atomic_uint_fast64_t next_seed = 0;

FILE *outp;

static inline float single(Xoroshiro *px, uint64_t xlo, uint64_t xhi){
    uint64_t lo=xNextLong(px), hi=xNextLong(px);
    Xoroshiro xr={lo^xlo, hi^xhi}; xSkipN(&xr,1);
    return fabsf(((uint32_t)(xNextLong(&xr)>>32)&0xFFFFFF)*5.960464478E-8f - 0.5f);
}

static int crunch(uint64_t seed){
  Xoroshiro xr; xSetSeed(&xr, seed);
  uint64_t lo=xNextLong(&xr), hi=xNextLong(&xr);

  Xoroshiro w0={lo^0xefc8ef4d36102b34, hi^0x1beeeb324a0f24ea};
  float w0ab=single(&w0,0xf11268128982754f,0x257a1d670430b0aa); if (w0ab > 0.2f) return 0;
  w0ab+=single(&w0,0xf11268128982754f,0x257a1d670430b0aa); if (w0ab > 0.3f) return 0;

  Xoroshiro e0={lo^0xd02491e6058f6fd8, hi^0x4792512c94c17a80};
  float e0ab=single(&e0,0x082fe255f8be6631,0x4e96119e22dedc81); if (e0ab > 0.2f) return 0;
  e0ab+=single(&e0,0x082fe255f8be6631,0x4e96119e22dedc81); if (e0ab > 0.4f) return 0;

  return 1;
}

static double sample(BiomeNoise *bn, int a, int b, int x, int z) {
  double v = 0;
  if (a) {
    OctaveNoise *on = &bn->climate[bn->nptype].octA;
    for (int i = 0; i < on->octcnt; i++) {
      if (a & (1 << i)) {
        PerlinNoise *pn = on->octaves + i;
        double l = pn->lacunarity;
        v += samplePerlin(pn, x * l, 0, z * l, 0, 0) * pn->amplitude;
      }
    }
  }
  if (b) {
    OctaveNoise *on = &bn->climate[bn->nptype].octB;
    for (int i = 0; i < on->octcnt; i++) {
      if (b & (1 << i)) {
        PerlinNoise *pn = on->octaves + i;
        double l = pn->lacunarity * (337.0 / 331.0);
        v += samplePerlin(pn, x * l, 0, z * l, 0, 0) * pn->amplitude;
      }
    }
  }
  return v * bn->climate[bn->nptype].amplitude;
}

static int eval1(int x, int z, void *data){ return getBiomeAt((Generator*)data, 4, x, 64, z) == stony_peaks; }
static int eval2(int x, int z, void *data){ return getBiomeAt((Generator*)data, 4, x, 64, z) == jagged_peaks; }
static int eval3(int x, int z, void *data){ return getBiomeAt((Generator*)data, 4, x, 64, z) == frozen_peaks; }

static int flood(void *data, int x, int z, int (*eval)(int, int, void*)) {
    int origin_x = x / 4;
    int origin_z = z / 4;
    uint8_t visited[192][192] = {0};
    int queue_x[36864];
    int queue_z[36864];
    int head = 0;
    int tail = 0;
    int area = 0;
    int64_t sum_x = 0;
    int64_t sum_z = 0;
    visited[96][96] = 1;
    queue_x[tail] = 96;
    queue_z[tail] = 96;
    tail++;
    while (head < tail)
    {
        int lx = queue_x[head];
        int lz = queue_z[head];
        int target_x = lx + origin_x - 96;
        int target_z = lz + origin_z - 96;
        head++;
        area++;
        sum_x += (int64_t)target_x;
        sum_z += (int64_t)target_z;
        int dx[4] = {1, -1, 0, 0};
        int dz[4] = {0, 0, 1, -1};
        for (int i = 0; i < 4; i++)
        {
            int nx = lx + dx[i];
            int nz = lz + dz[i];
            if (nx >= 0 && nx < 192 && nz >= 0 && nz < 192 && !visited[nz][nx])
            {
                visited[nz][nx] = 1;
                int n_target_x = nx + origin_x - 96;
                int n_target_z = nz + origin_z - 96;
                int result = eval(n_target_x * 4, n_target_z * 4, data);
                if (result == 1)
                {
                    queue_x[tail] = nx;
                    queue_z[tail] = nz;
                    tail++;
                }
                else if (result == -1)
                {
                    return 0;
                }
            }
        }
    }
    return area * 16;
}

static int begin(Generator *g, ClimateNoises *n, uint64_t seed) {
  setClimateParaSeed(n->e, seed, 0, NP_EROSION, 2);
  double ev = sample(n->e, 0b1, 0b0, 0, 0);
  if (ev > -0.3500) return 0;
  ev+=sample(n->e, 0b0, 0b1, 0, 0);
  if (ev > -0.6000) return 0;
  bool a = sample(n->e, 0b1, 0b1, 0, -375) < -0.4500;
  bool b = sample(n->e, 0b1, 0b1, 325, 187) < -0.4500;
  bool c = sample(n->e, 0b1, 0b1, -325, 187) < -0.4500; 
  if (!(a||b||c)) return 0;
  int cnt = 0;
  double map[5][5] = {0.0000};
  setClimateParaSeed(n->e, seed, 0, NP_EROSION, 4);
  for (int x=0; x<=4; x++) {
    for (int z=0; z<=4; z++) {
      map[x][z] = sample(n->e, 0b11, 0b11, (x-2)*128, (z-2)*128);
      if (map[x][z] < -0.8000) cnt++;
    }
  }
  if (cnt < 4) return 0;
  setClimateParaSeed(n->c, seed, 0, NP_CONTINENTALNESS, 2);
  int cr[2] = {0, 0}; double rs = 0.0000;
  for (int x=0; x<=4; x++) {
    for (int z=0; z<=4; z++) {
      double rp = map[x][z];
      if (rp > -0.8000) continue; 
      if (rs < rp) continue;
      if (sample(n->c, 0b1, 0b1, (x-2)*128, (z-2)*128) < 0.1000) continue;
      rs = rp, cr[0] = x, cr[1] = z;
    }
  }
  if (rs >= 0) return 0;
  setClimateParaSeed(n->w, seed, 0, NP_WEIRDNESS, 4);
  int pos = 0, neg = 0, x = (cr[0]-2)*128, z = (cr[1]-2)*128;
  for (int x1=x-192; x1<=x+192; x1+=32) {
    for (int z1=z-192; z1<=z+192; z1+=32) {
      double sm = sample(n->w, 0b11, 0b11, x1, z1);
      if (sm > 0.4000) pos++;
      if (sm < -0.4000) neg++;
    }
  }
  if (pos < 35 && neg < 35) return 0;
  int sign = 0;
  if (pos > neg) {
    sign = 1;
  } else {
    sign = -1;
  }
  int cnt1 = 0;
  setClimateParaSeed(n->t, seed, 0, NP_TEMPERATURE, 2);
  setClimateParaSeed(n->c, seed, 0, NP_CONTINENTALNESS, 6);
  for (int x1=x-256; x1<=x+256; x1+=16) {
    for (int z1=z-256; z1<=z+256; z1+=16) {
      double prec1 = sample(n->w, 0b11, 0b11, x1, z1);
      if (prec1*sign < 0.4000) continue;
      double prec2 = sample(n->e, 0b11, 0b11, x1, z1);
      if (prec2 > -0.7800) continue;
      double prec3 = sample(n->c, 0b111, 0b111, x1, z1);
      if (prec3 < 0.0300) continue;
      cnt1++;
    }
  }
  if (cnt1 < 120) return 0;
  //printf("%d %d\n", pos, neg);
  setClimateParaSeed(n->t, seed, 0, NP_TEMPERATURE, 4);
  setClimateParaSeed(n->w, seed, 0, NP_WEIRDNESS, 6);
  setClimateParaSeed(n->e, seed, 0, NP_EROSION, 8);
  setClimateParaSeed(n->c, seed, 0, NP_CONTINENTALNESS, 8);
  int fr = 0, res = 0, b1 = 0;
  applySeed(g, DIM_OVERWORLD, seed);
  for (int x1=x-128; x1<=x+128; x1+=64) {
    for (int z1=z-128; z1<=z+128; z1+=64) {
      double cl1 = sample(n->t, 0b11, 0b11, x1, z1);
      double cl2 = sample(n->w, 0b111, 0b111, x1, z1);
      double cl3 = sample(n->e, 0b1111, 0b1111, x1, z1);
      double cl4 = sample(n->c, 0b1111, 0b1111, x1, z1);
      if (cl1 > 0.5500) continue;
      if (cl2*sign < 0.4000) continue;
      if (cl3 > -0.7800) continue;
      if (cl4 < 0.0300) continue;
      //printf("checks");
      if (cl1 >= 0.2000) {
        res = flood(g, x1, z1, eval1);
        if (res > fr) {fr = res; b1 = 0;}
      }
      if (cl1 < 0.2000 && sign < 0) {
        res = flood(g, x1, z1, eval2);
        if (res > fr) {fr = res; b1 = 1;}
      } else {
        res = flood(g, x1, z1, eval3);
        if (res > fr) {fr = res; b1 = 2;}
      }
    }
  }
  if (fr < MIN_SIZE) return 0;
  char bl[3][13] = {"Stony Peaks", "Jagged Peaks", "Frozen Peaks"};
  printf("Seed %" PRId64 " Size 1:4 %d %s\n", seed, fr, bl[b1]);
  if (MINIMALIST_OUTPUT) {
    fprintf(outp, "%" PRId64 "\n", seed);
    fflush(outp);
  } else {
    fprintf(outp, "Seed %" PRId64 " Size 1:4 %d %s\n", seed, fr, bl[b1]);
    fflush(outp);
  }
  return 1;
}

static void *worker(void *arg) {
  Generator g;
  setupGenerator(&g, MC_NEWEST, 0);
  BiomeNoise t, h, c, e, w;
  t = h = c = e = w = g.bn;
  ClimateNoises n = {&t, &h, &c, &e, &w};
  while (1) {
    uint64_t start = atomic_fetch_add(&next_seed, BATCH_SIZE);
    uint64_t end = start + BATCH_SIZE;
    for (uint64_t seed = start; seed < end; seed++) {
      if (!crunch(seed)) continue;
      begin(&g, &n, seed);
    }
  }
  return NULL;
}

int main(void) {
  srand((unsigned int)time(NULL));
  uint64_t seed = 0;
  for (int i = 0; i < 4; i++) {
    seed = (seed << 16) | (uint64_t)(rand() & 0xFFFF);
  }
  atomic_store(&next_seed, seed);
  outp = fopen("output.txt", "a");
  pthread_t threads[THREADS];
  for (int i = 0; i < THREADS; i++) {
    pthread_create(&threads[i], NULL, worker, NULL);
  }
  for (int i = 0; i < THREADS; i++) {
    pthread_join(threads[i], NULL);
  }
  return 0;
}
